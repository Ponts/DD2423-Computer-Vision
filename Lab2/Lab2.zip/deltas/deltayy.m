function mask = deltayy()
    mask = [0;1; -2; 1;0];
end