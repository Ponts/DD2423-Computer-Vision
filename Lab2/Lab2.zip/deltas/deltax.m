function mask = deltax()
    mask = [0, -0.5, 0, 0.5,0];
end

