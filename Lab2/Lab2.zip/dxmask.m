function mask = dxmask()
    %Returns the sobel operator in x
    mask = [1 0 -1; 2 0 -2; 1 0 -1];
end

